$(document).ready(() => {
  $("#button").click(e => {
    e.preventDefault();
    $("#button").addClass("is-loading");
    $("#error").hide();
    $("#email").removeClass("is-danger");
    $("#password").removeClass("is-danger");
    const email = $("#email").val();
    const password = $("#password").val();

    $.ajax({
      type: "post",
      url: "./signIn.php",
      dataType: "json",
      data: { email, password },
      success: data => {
        $("#button").removeClass("is-loading");
        if (data.success == true) {
          localStorage.setItem("token", "zelqtg");
          window.location.href = "admin.html";
        } else {
          $("#error").show();
          $("#email").addClass("is-danger");
          $("#password").addClass("is-danger");
        }
      },
      error: () => {
        $("#button").removeClass("is-loading");
        $("#error").show();
        $("#email").addClass("is-danger");
        $("#password").addClass("is-danger");
      }
    });
  });
});
